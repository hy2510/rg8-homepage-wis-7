import RenewType from '@/util/string-utils'

export type Customer = {
  customerId: string
  name: string
  areaCode: string
  customerGroupCode: string
  customerGroupName: string
  customerUseCode: string
  customerTypeCode: string
  round: number
  customerOldId: string
  postcode: string
  address: string
  detailAddress: string
  cellPhone: string
  telephone: string
  fax: string
  payTypeCode: string
  ceoName: string
  businessNo: string
  logoFilename: string
  bankCode: string
  accountNo: number
  memo: string
  expiredDate: string
  useYn: boolean
  deleteYn: boolean
  schoolYn: boolean
  viewPopupYn: boolean
  reportYn: boolean
  studyReportYn: boolean
  monthReportYn: boolean
  yearReportYn: boolean
  teacherEvaluation: string
  autoLevelUpYn: boolean
  viewVocaYn: boolean
  viewAssessmentYn: boolean
  viewLevelUpYn: boolean
  limitLevelYn: boolean
  minLevel: number
  maxLevel: number
  urlCode1: number
  urlCode2: string
  serviceYn: boolean
  iniKeyCode: string
  customerUse: string
  selfStudyYn: boolean
  wholeSchoolYn: boolean
  languageCode: string
  viewPbTypeSetupYn: boolean
  viewFullEasyYn: boolean
  countryCode: string
  mainBannerViewYn: boolean
  useEbookAniYn: boolean
  studentWorkSheetYn: boolean
  managerWorkSheetYn: boolean
  viewRecommendBooksYn: boolean
  needPayment: string
  studyEBUseYn: boolean
  studyPBUseYn: boolean
  studyLCUseYn: boolean
  studyMSUseYn: boolean
  studyPDUseYn: boolean
  studyJNUseYn: boolean
  studyESUseYn: boolean
  useDodoAbcYn: string
  useSpeakYn: boolean
  useStudentNoYn: boolean
  preKMode: string
  programModelCode: string
  programModelName: string
}

export function makeCustomer(json?: any): Customer {
  return {
    customerId: RenewType.renewString(json?.CustomerId),
    name: RenewType.renewString(json?.Name),
    areaCode: RenewType.renewString(json?.AreaCode),
    customerGroupCode: RenewType.renewString(json?.CustomerGroupCode),
    customerGroupName: RenewType.renewString(json?.CustomerGroupName),
    customerUseCode: RenewType.renewString(json?.CustomerUseCode),
    customerTypeCode: RenewType.renewString(json?.CustomerTypeCode),
    round: RenewType.renewNumber(json?.Round),
    customerOldId: RenewType.renewString(json?.CustomerOldId),
    postcode: RenewType.renewString(json?.Postcode),
    address: RenewType.renewString(json?.Address),
    detailAddress: RenewType.renewString(json?.DetailAddress),
    cellPhone: RenewType.renewString(json?.CellPhone),
    telephone: RenewType.renewString(json?.Telephone),
    fax: RenewType.renewString(json?.Fax),
    payTypeCode: RenewType.renewString(json?.PayTypeCode),
    ceoName: RenewType.renewString(json?.CeoName),
    businessNo: RenewType.renewString(json?.BusinessNo),
    logoFilename: RenewType.renewString(json?.LogoFilename),
    bankCode: RenewType.renewString(json?.BankCode),
    accountNo: RenewType.renewNumber(json?.AccountNo),
    memo: RenewType.renewString(json?.Memo),
    expiredDate: RenewType.renewString(json?.ExpiredDate),
    useYn: RenewType.renewBoolean(json?.UseYn),
    deleteYn: RenewType.renewBoolean(json?.DeleteYn),
    schoolYn: RenewType.renewBoolean(json?.SchoolYn),

    viewPopupYn: RenewType.renewBoolean(json?.ViewPopupYn),
    reportYn: RenewType.renewBoolean(json?.ReportYn),
    studyReportYn: RenewType.renewBoolean(json?.StudyReportYn),
    monthReportYn: RenewType.renewBoolean(json?.MonthReportYn),
    yearReportYn: RenewType.renewBoolean(json?.YearReportYn),
    teacherEvaluation: RenewType.renewString(json?.TeacherEvaluation),
    autoLevelUpYn: RenewType.renewBoolean(json?.AutoLevelUpYn),
    viewVocaYn: RenewType.renewBoolean(json?.ViewVocaYn),
    viewAssessmentYn: RenewType.renewBoolean(json?.ViewAssessmentYn),
    viewLevelUpYn: RenewType.renewBoolean(json?.ViewLevelUpYn),
    limitLevelYn: RenewType.renewBoolean(json?.LimitLevelYn),
    minLevel: RenewType.renewNumber(json?.MinLevel),
    maxLevel: RenewType.renewNumber(json?.MaxLevel),
    urlCode1: RenewType.renewNumber(json?.UrlCode1),
    urlCode2: RenewType.renewString(json?.UrlCode2),
    serviceYn: RenewType.renewBoolean(json?.ServiceYn),
    iniKeyCode: RenewType.renewString(json?.IniKeyCode),
    customerUse: RenewType.renewString(json?.CustomerUse),
    selfStudyYn: RenewType.renewBoolean(json?.SelfStudyYn),
    wholeSchoolYn: RenewType.renewBoolean(json?.WholeSchoolYn),
    languageCode: RenewType.renewString(json?.LanguageCode),
    viewPbTypeSetupYn: RenewType.renewBoolean(json?.ViewPbTypeSetupYn),
    viewFullEasyYn: RenewType.renewBoolean(json?.ViewFullEasyYn),
    countryCode: RenewType.renewString(json?.CountryCode),
    mainBannerViewYn: RenewType.renewBoolean(json?.MainBannerViewYn),
    useEbookAniYn: RenewType.renewBoolean(json?.UseEbookAniYn),
    studentWorkSheetYn: RenewType.renewBoolean(json?.StudentWorkSheetYn),
    managerWorkSheetYn: RenewType.renewBoolean(json?.ManagerWorkSheetYn),
    viewRecommendBooksYn: RenewType.renewBoolean(json?.ViewRecommendBooksYn),
    needPayment: RenewType.renewString(json?.NeedPayment),
    studyEBUseYn: RenewType.renewBoolean(json?.StudyEBUseYn),
    studyPBUseYn: RenewType.renewBoolean(json?.StudyPBUseYn),
    studyLCUseYn: RenewType.renewBoolean(json?.StudyLCUseYn),
    studyMSUseYn: RenewType.renewBoolean(json?.StudyMSUseYn),
    studyPDUseYn: RenewType.renewBoolean(json?.StudyPDUseYn),
    studyJNUseYn: RenewType.renewBoolean(json?.StudyJNUseYn),
    studyESUseYn: RenewType.renewBoolean(json?.StudyESUseYn),
    useDodoAbcYn: RenewType.renewString(json?.UseDodoAbcYn),
    useSpeakYn: RenewType.renewBoolean(json?.UseSpeakYn),
    useStudentNoYn: RenewType.renewBoolean(json?.UseStudentNoYn),
    preKMode: RenewType.renewString(json?.PreKMode),
    programModelCode: RenewType.renewString(json?.ProgramModelCode),
    programModelName: RenewType.renewString(json?.ProgramModelName),
  }
}

export function parseCustomer(json?: string): {
  Token: string
  Customer: Customer
} {
  if (!json) {
    return {
      Token: '',
      Customer: makeCustomer(),
    }
  }
  const obj = JSON.parse(json)
  return {
    Token: RenewType.renewString(obj?.Token),
    Customer: makeCustomer(obj?.Customer),
  }
}
