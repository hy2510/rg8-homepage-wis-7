import { execute, makeRequest } from '@/8th/shared/http'
import RenewType from '@/util/string-utils'

export type BookDetailInfo = {
  bookId: string
  title: string
  author: string
  publisher: string
  genre: string
  theme: string
  preferenceAverage: number
  bookLevel: string
  rgPoint: number
  readCount: number
  pages: number
  wordCount: number
  surfaceImage: string
  keywords: string
  grade: string
  readerLevel: string
  synopsis: string
  bookCode: string
  studentId: string
  studyId: string
  studentHistoryId: string
  studyStatus: string
  getRgPoint: number
  scoreStep1: number
  scoreStep2: number
  scoreStep3: number
  scoreStep4: number
  scoreStep5: number
  scoreStep6: number
  average: number
  registDate: string
  endDate: string
  fullEasyCode: string
  recentlyEndDate: string
  recentlyFullEasyCode: string
  passCount: number
  totalCompleteCount: number
  className: string
  fullEasyYn: boolean
  recommendedAge: string
  seriesName: string
  oldBookCode: string
  openDate: string
  studyStartedYn: boolean
  classId: string
  sampleYn: boolean
  modifyedRgPoint: number
  addStudyCount: number
  todayStudyYn: boolean
  assignedYn: boolean
  firstFullEasyCode: string
  secondFullEasyCode: string
  animationPath: string
  bookMarkYn: boolean
  backgroundImage: string
  writingStatusCode: string
  revisionStatusCode: string
  deleteYn: boolean
  price: number
  priceCd: string
  gameLandRoundOpenYn: boolean
  readingCompletedEB: string
  speakPassYn: boolean
  highlightDataYn: boolean
  infoType: string
  studyMode: string
  secondRgPoint: number
  userRgPoint: number
  studyTypeFullEasyYn: boolean
  speakContentYn: boolean
  levelRoundId: string
  workSheetPath: string
  vocabularyPath: string
  reportPath: string
  expiredContentsYn: boolean
}

function makeBookDetailInfo(json?: any): BookDetailInfo {
  return {
    bookId: RenewType.renewString(json?.BookId),
    title: RenewType.renewString(json?.Title),
    author: RenewType.renewString(json?.Author),
    publisher: RenewType.renewString(json?.Publisher),
    genre: RenewType.renewString(json?.Genre),
    theme: RenewType.renewString(json?.Theme),
    preferenceAverage: RenewType.renewNumber(json?.PreferenceAverage),
    bookLevel: RenewType.renewString(json?.BookLevel),
    rgPoint: RenewType.renewNumber(json?.RgPoint),
    readCount: RenewType.renewNumber(json?.ReadCount),
    pages: RenewType.renewNumber(json?.Pages),
    wordCount: RenewType.renewNumber(json?.WordCount),
    surfaceImage: RenewType.renewString(json?.SurfaceImage),
    keywords: RenewType.renewString(json?.Keywords),
    grade: RenewType.renewString(json?.Grade),
    readerLevel: RenewType.renewString(json?.ReaderLevel),
    synopsis: RenewType.renewString(json?.Synopsis),
    bookCode: RenewType.renewString(json?.BookCode),
    studentId: RenewType.renewString(json?.StudentId),
    studyId: RenewType.renewString(json?.StudyId),
    studentHistoryId: RenewType.renewString(json?.StudentHistoryId),
    studyStatus: RenewType.renewString(json?.StudyStatus),
    getRgPoint: RenewType.renewNumber(json?.GetRgPoint),
    scoreStep1: RenewType.renewNumber(json?.ScoreStep1),
    scoreStep2: RenewType.renewNumber(json?.ScoreStep2),
    scoreStep3: RenewType.renewNumber(json?.ScoreStep3),
    scoreStep4: RenewType.renewNumber(json?.ScoreStep4),
    scoreStep5: RenewType.renewNumber(json?.ScoreStep5),
    scoreStep6: RenewType.renewNumber(json?.ScoreStep6),
    average: RenewType.renewNumber(json?.Average),
    registDate: RenewType.renewString(json?.RegistDate),
    endDate: RenewType.renewString(json?.EndDate),
    fullEasyCode: RenewType.renewString(json?.FullEasyCode),
    recentlyEndDate: RenewType.renewString(json?.RecentlyEndDate),
    recentlyFullEasyCode: RenewType.renewString(json?.RecentlyFullEasyCode),
    passCount: RenewType.renewNumber(json?.PassCount),
    totalCompleteCount: RenewType.renewNumber(json?.TotalCompleteCount),
    className: RenewType.renewString(json?.ClassName),
    fullEasyYn: RenewType.renewBoolean(json?.FullEasyYn),
    recommendedAge: RenewType.renewString(json?.RecommendedAge),
    seriesName: RenewType.renewString(json?.SeriesName),
    oldBookCode: RenewType.renewString(json?.OldBookCode),
    openDate: RenewType.renewString(json?.OpenDate),
    studyStartedYn: RenewType.renewBoolean(json?.StudyStartedYn),
    classId: RenewType.renewString(json?.ClassId),
    sampleYn: RenewType.renewBoolean(json?.SampleYn),
    modifyedRgPoint: RenewType.renewNumber(json?.ModifyedRgPoint),
    addStudyCount: RenewType.renewNumber(json?.AddStudyCount),
    todayStudyYn: RenewType.renewBoolean(json?.TodayStudyYn),
    assignedYn: RenewType.renewBoolean(json?.AssignedYn),
    firstFullEasyCode: RenewType.renewString(json?.FirstFullEasyCode),
    secondFullEasyCode: RenewType.renewString(json?.SecondFullEasyCode),
    animationPath: RenewType.renewString(json?.AnimationPath),
    bookMarkYn: RenewType.renewBoolean(json?.BookMarkYn),
    backgroundImage: RenewType.renewString(json?.BackgroundImage),
    writingStatusCode: RenewType.renewString(json?.WritingStatusCode),
    revisionStatusCode: RenewType.renewString(json?.RevisionStatusCode),
    deleteYn: RenewType.renewBoolean(json?.DeleteYn),
    price: RenewType.renewNumber(json?.Price),
    priceCd: RenewType.renewString(json?.PriceCd),
    gameLandRoundOpenYn: RenewType.renewBoolean(json?.GameLandRoundOpenYn),
    readingCompletedEB: RenewType.renewString(json?.ReadingCompletedEB),
    speakPassYn: RenewType.renewBoolean(json?.SpeakPassYn),
    highlightDataYn: RenewType.renewBoolean(json?.HighlightDataYn),

    infoType: RenewType.renewString(json?.InfoType),
    studyMode: RenewType.renewString(json?.StudyMode),
    userRgPoint: RenewType.renewNumber(json?.UserRgPoint),
    secondRgPoint: RenewType.renewNumber(json?.SecondRgPoint),
    studyTypeFullEasyYn: RenewType.renewBoolean(json?.StudyTypeFullEasyYn),
    speakContentYn: RenewType.renewBoolean(json?.SpeakContentYn),
    levelRoundId: RenewType.renewString(json?.LevelRoundId),
    workSheetPath: RenewType.renewString(json?.WorkSheetPath),
    vocabularyPath: RenewType.renewString(json?.VocabularyPath),
    reportPath: RenewType.renewString(json?.ReportPath),
    expiredContentsYn: RenewType.renewBoolean(json?.ExpiredContentsYn),
  }
}

function transform(json: any): BookDetailInfoResponse {
  return makeBookDetailInfo(json)
}

export type BookDetailInfoParams = {
  levelRoundId: string
  studyId?: string
  studentHistoryId?: string
}

export type BookDetailInfoResponse = BookDetailInfo

export async function getBookDetailInfo(
  input: BookDetailInfoParams,
): Promise<BookDetailInfoResponse> {
  const request = makeRequest(`api/library/book-info`, {
    method: 'get',
    queryString: {
      levelRoundId: input.levelRoundId,
      studyId: input.studyId,
      studentHistoryId: input.studentHistoryId,
    },
  })
  return await execute(request, transform)
}
