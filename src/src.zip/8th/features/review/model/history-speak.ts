import { execute, makeRequest } from '@/8th/shared/http'
import RenewType from '@/util/string-utils'

export type HistorySpeak = {
  no: number
  no2: number
  studyId: string
  levelId: string
  levelRoundId: string
  registDate: string
  registId: string
  classId: string
  className: string
  studentHistoryId: string
  studentId: string
  name: string
  nameEng: string
  courseName: string
  levelName: string
  bookId: string
  title: string
  assigner: string
  assignDate: string
  openDate: string
  dueDate: string
  completeDate: string
  scoreStep1: number
  scoreStep2: number
  scoreStep3: number
  scoreStep4: number
  scoreStep5: number
  average: number
  reTest: number
  rgPoint: number
  bonusPoint: number
  preference: number
  statusCode: string
  statusName: string
  deleteYn: boolean
  revisionStatusCode: string
  surfaceImagePath: string
  previewImage1: string
  previewImage2: string
  previewImage3: string
  previewImage4: string
  theme: string
  seriesName: string
  story: string
  preferenceAverage: number
  publisherType: string
  sortOrder: string
  courseCode: string
  readingCount: number
  readingCount2: number
  listeningCount: number
  writingCount: number
  revisionFinishCount: number
  revisionOngoingCount: number
  brRevisionFinishCount: number
  brRevisionOngoingCount: number
  lcRevisionFinishCount: number
  lcRevisionOngoingCount: number
  wrRevisionFinishCount: number
  wrRevisionOngoingCount: number
  rgPointCount: number
  answerCount: number
  cntStudyDays: number
  fullEasyMode: string
  fullEasyMode_Org: string
  storySoundPath: string
  oldBookCode: string
  bookPoint: number
  author: string
  publisher: string
  isbn: string
  workBookPrintYn: boolean
  animationPath: string
  revisionStatusName: string
  revisionSubmitDate: string
  readingCompletedEB: string
  speakPassYn: boolean
  speakDate: string
}

function makeHistorySpeak(json: any): HistorySpeak {
  return {
    no: RenewType.renewNumber(json?.No),
    no2: RenewType.renewNumber(json?.No2),
    studyId: RenewType.renewString(json?.StudyId),
    levelId: RenewType.renewString(json?.LevelId),
    levelRoundId: RenewType.renewString(json?.LevelRoundId),
    registDate: RenewType.renewString(json?.RegistDate),
    registId: RenewType.renewString(json?.RegistId),
    classId: RenewType.renewString(json?.ClassId),
    className: RenewType.renewString(json?.ClassName),
    studentHistoryId: RenewType.renewString(json?.StudentHistoryId),
    studentId: RenewType.renewString(json?.StudentId),
    name: RenewType.renewString(json?.Name),
    nameEng: RenewType.renewString(json?.NameEng),
    courseName: RenewType.renewString(json?.CourseName),
    levelName: RenewType.renewString(json?.LevelName),
    bookId: RenewType.renewString(json?.BookId),
    title: RenewType.renewString(json?.Title),
    assigner: RenewType.renewString(json?.Assigner),
    assignDate: RenewType.renewString(json?.AssignDate),
    openDate: RenewType.renewString(json?.OpenDate),
    dueDate: RenewType.renewString(json?.DueDate),
    completeDate: RenewType.renewString(json?.CompleteDate),
    scoreStep1: RenewType.renewNumber(json?.ScoreStep1),
    scoreStep2: RenewType.renewNumber(json?.ScoreStep2),
    scoreStep3: RenewType.renewNumber(json?.ScoreStep3),
    scoreStep4: RenewType.renewNumber(json?.ScoreStep4),
    scoreStep5: RenewType.renewNumber(json?.ScoreStep5),
    average: RenewType.renewNumber(json?.Average),
    reTest: RenewType.renewNumber(json?.ReTest),
    rgPoint: RenewType.renewNumber(json?.RgPoint),
    bonusPoint: RenewType.renewNumber(json?.BonusPoint),
    preference: RenewType.renewNumber(json?.Preference),
    statusCode: RenewType.renewString(json?.StatusCode),
    statusName: RenewType.renewString(json?.StatusName),
    deleteYn: RenewType.renewBoolean(json?.DeleteYn),
    revisionStatusCode: RenewType.renewString(json?.RevisionStatusCode),
    surfaceImagePath: RenewType.renewString(json?.SurfaceImagePath),
    previewImage1: RenewType.renewString(json?.PreviewImage1),
    previewImage2: RenewType.renewString(json?.PreviewImage2),
    previewImage3: RenewType.renewString(json?.PreviewImage3),
    previewImage4: RenewType.renewString(json?.PreviewImage4),
    theme: RenewType.renewString(json?.Theme),
    seriesName: RenewType.renewString(json?.SeriesName),
    story: RenewType.renewString(json?.Story),
    preferenceAverage: RenewType.renewNumber(json?.PreferenceAverage),
    publisherType: RenewType.renewString(json?.PublisherType),
    sortOrder: RenewType.renewString(json?.SortOrder),
    courseCode: RenewType.renewString(json?.CourseCode),
    readingCount: RenewType.renewNumber(json?.ReadingCount),
    readingCount2: RenewType.renewNumber(json?.ReadingCount2),
    listeningCount: RenewType.renewNumber(json?.ListeningCount),
    writingCount: RenewType.renewNumber(json?.WritingCount),
    revisionFinishCount: RenewType.renewNumber(json?.RevisionFinishCount),
    revisionOngoingCount: RenewType.renewNumber(json?.RevisionOngoingCount),
    brRevisionFinishCount: RenewType.renewNumber(json?.BrRevisionFinishCount),
    brRevisionOngoingCount: RenewType.renewNumber(json?.BrRevisionOngoingCount),
    lcRevisionFinishCount: RenewType.renewNumber(json?.LcRevisionFinishCount),
    lcRevisionOngoingCount: RenewType.renewNumber(json?.LcRevisionOngoingCount),
    wrRevisionFinishCount: RenewType.renewNumber(json?.WrRevisionFinishCount),
    wrRevisionOngoingCount: RenewType.renewNumber(json?.WrRevisionOngoingCount),
    rgPointCount: RenewType.renewNumber(json?.RgPointCount),
    answerCount: RenewType.renewNumber(json?.AnswerCount),
    cntStudyDays: RenewType.renewNumber(json?.CntStudyDays),
    fullEasyMode: RenewType.renewString(json?.FullEasyMode),
    fullEasyMode_Org: RenewType.renewString(json?.FullEasyMode_Org),
    storySoundPath: RenewType.renewString(json?.StorySoundPath),
    oldBookCode: RenewType.renewString(json?.OldBookCode),
    bookPoint: RenewType.renewNumber(json?.BookPoint),
    author: RenewType.renewString(json?.Author),
    publisher: RenewType.renewString(json?.Publisher),
    isbn: RenewType.renewString(json?.ISBN),
    workBookPrintYn: RenewType.renewBoolean(json?.WorkBookPrintYn),
    animationPath: RenewType.renewString(json?.AnimationPath),
    revisionStatusName: RenewType.renewString(json?.RevisionStatusName),
    revisionSubmitDate: RenewType.renewString(json?.RevisionSubmitDate),
    readingCompletedEB: RenewType.renewString(json?.ReadingCompletedEB),
    speakPassYn: RenewType.renewBoolean(json?.SpeakPassYn),
    speakDate: RenewType.renewString(json?.SpeakDate),
  }
}

function transform(json: any): HistorySpeakResponse {
  return {
    history: json.History.map((item: any) => {
      return makeHistorySpeak(item)
    }),
  }
}

export type HistorySpeakParams = {
  startDate: string
  endDate: string
  status: string
}

export type HistorySpeakResponse = {
  history: HistorySpeak[]
}

export async function getHistorySpeak(
  input: HistorySpeakParams,
): Promise<HistorySpeakResponse> {
  const request = makeRequest(`api/history/speaking`, {
    method: 'get',
    queryString: {
      startDate: input.startDate || '',
      endDate: input.endDate || '',
      status: input.status,
    },
  })
  return await execute(request, transform)
}
